<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomAuthController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/login', [CustomAuthController::class, 'login'])->middleware('alreadyLoggedIn');
Route::get('/registration', [CustomAuthController::class, 'registration'])->middleware('alreadyLoggedIn');
Route::post('/register-user', [CustomAuthController::class, 'registerUser']) ->name('register-user');
Route::get('/login-user', [CustomAuthController::class, 'loginUser']) ->name('login-user');
Route::get('/dashboard', [CustomAuthController::class, 'dashboard'])-> middleware('isLoggedIn');
Route::get('/logout', [CustomAuthController::class, 'logout']);
Route::get('/ulbregistration', [CustomAuthController::class, 'ulbregistration']);
Route::post('/register-ulb', [CustomAuthController::class, 'registerUlb']) ->name('register-ulb');
Route::get('/ulblist', [CustomAuthController::class, 'ulbList']);
Route::get('/ulblogin', [CustomAuthController::class, 'ulbLogin']);
Route::get('/login-ulb', [CustomAuthController::class, 'loginUlb']) ->name('login-ulb');
Route::get('/stateportalreg', [CustomAuthController::class, 'stateportalreg']);
Route::post('/register-stateportal', [CustomAuthController::class, 'registerStatePortal']) ->name('register-stateportal');
Route::get('/stateportallogin', [CustomAuthController::class, 'stateportallogin']);
Route::get('/login-stateportal', [CustomAuthController::class, 'loginStatePortal']) ->name('login-stateportal');
Route::get('/captcha', [CustomAuthController::class, 'generateRandomCaptcha']);
Route::get('/chart', [CustomAuthController::class, 'showChart']);
Route::get('/distportalreg', [CustomAuthController::class, 'distportalreg']);
Route::post('/register-distportal', [CustomAuthController::class, 'registerDistPortal']) ->name('register-distportal');
Route::get('/distportallogin', [CustomAuthController::class, 'distportallogin']);
Route::get('/login-distportal', [CustomAuthController::class, 'loginDistPortal']) ->name('login-distportal');
Route::get('/get-districts/{sambhagId}',[CustomAuthController::class, 'getDistricts']);
Route::get('/get-nagarnigam/{districtId}',[CustomAuthController::class, 'getNagarNigam']);
Route::get('/get-nagarpalika/{districtId}',[CustomAuthController::class, 'getNagarPalika']);
Route::get('/get-nagarpanchayat/{districtId}',[CustomAuthController::class, 'getNagarPanchayat']);






